﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SalonZSample.Models;

namespace SalonZSample.Data
{
    public class SalonZSampleContext : DbContext
    {
        public SalonZSampleContext (DbContextOptions<SalonZSampleContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<SalonZSample.Models.Customer> Customer { get; set; }
    }
}
