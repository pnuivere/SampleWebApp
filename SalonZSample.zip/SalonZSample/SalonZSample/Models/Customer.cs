﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SalonZSample.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Address { get; set; }
        [Display(Name = "Profile Image")]
        public string ProfileImage { get; set; }
        public string Gender { get; set; }
        [Display(Name = "Contact Number")]
        public string ContactNumber { get; set; }
        [Display(Name = "How did you find out about us?")]
        public string Source { get; set; }

        [NotMapped]
        public SelectList Sources { get; set; }
        [NotMapped]
        public SelectList GenderChoices { get; set; }
        [NotMapped]
        [Display(Name="Upload Image")]
        public IFormFile ImageFile { get; set; }
    }
}
