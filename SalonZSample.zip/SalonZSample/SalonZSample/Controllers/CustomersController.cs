﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalonZSample.Data;
using SalonZSample.Models;
using Microsoft.AspNetCore.Hosting;

namespace SalonZSample.Controllers
{
    public class CustomersController : Controller
    {
        private readonly SalonZSampleContext _context;
        private readonly IHostingEnvironment _hostingEnvironment;

        public CustomersController(SalonZSampleContext context, IHostingEnvironment hostingEnvironment)
        {
            _context = context;
            this._hostingEnvironment = hostingEnvironment;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            try
            {
                var customer = await _context.Customer?.ToListAsync();

                return View(await _context.Customer.ToListAsync());
            }
            catch (Exception e)
            {
                throw e;
            }            
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .FirstOrDefaultAsync(m => m.Id == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            var model = new Customer();
            DateTime dobVal = DateTime.Now.Date;
            model.DOB = dobVal;

            List<SelectListItem> sourceList = new List<SelectListItem>();
            sourceList.Add(new SelectListItem { Value = "Instagram", Text = "Instagram" });
            sourceList.Add(new SelectListItem { Value = "Facebook", Text = "Facebook" });
            sourceList.Add(new SelectListItem { Value = "Tiktok", Text = "Tiktok" });
            sourceList.Add(new SelectListItem { Value = "Email", Text = "Email" });
            sourceList.Add(new SelectListItem { Value = "TV", Text = "TV" });
            sourceList.Add(new SelectListItem { Value = "Others", Text = "Others" });

            List<SelectListItem> genderList = new List<SelectListItem>();
            genderList.Add(new SelectListItem { Value = "Male", Text = "Male" });
            genderList.Add(new SelectListItem { Value = "Female", Text = "Female" });

            model.Sources = new SelectList(sourceList, "Value", "Text");
            model.GenderChoices = new SelectList(genderList, "Value", "Text");
            return View(model);
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,DOB,Address,Gender,ContactNumber,Source,ImageFile")] Customer customer)
        {            
            if (ModelState.IsValid)
            {
                string rootFolder = _hostingEnvironment.WebRootPath + "\\Images\\";
                string fileName = Path.GetFileNameWithoutExtension(customer.ImageFile.FileName);
                string extension = Path.GetExtension(customer.ImageFile.FileName);
                customer.ProfileImage = fileName + "_" + DateTime.Now.ToString("ddMMyyyy") + extension;
                //create folder
                Directory.CreateDirectory(rootFolder);

                string filePath = Path.Combine(rootFolder, fileName);
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                    await customer.ImageFile.CopyToAsync(fs);
                }

                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            else
            {
                List<SelectListItem> sourceList = new List<SelectListItem>();
                sourceList.Add(new SelectListItem { Value = "Instagram", Text = "Instagram" });
                sourceList.Add(new SelectListItem { Value = "Facebook", Text = "Facebook" });
                sourceList.Add(new SelectListItem { Value = "Tiktok", Text = "Tiktok" });
                sourceList.Add(new SelectListItem { Value = "Email", Text = "Email" });
                sourceList.Add(new SelectListItem { Value = "TV", Text = "TV" });
                sourceList.Add(new SelectListItem { Value = "Others", Text = "Others" });

                List<SelectListItem> genderList = new List<SelectListItem>();
                genderList.Add(new SelectListItem { Value = "Male", Text = "Male" });
                genderList.Add(new SelectListItem { Value = "Female", Text = "Female" });

                customer.Sources = new SelectList(sourceList, "Value", "Text", customer.Source);
                customer.GenderChoices = new SelectList(genderList, "Value", "Text", customer.Gender);
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,DOB,Address,ProfileImage,Gender,ContactNumber,Source, ImageFile")] Customer customer)
        {
            if (id != customer.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    string rootFolder = _hostingEnvironment.WebRootPath + "\\Images\\";
                    string fileName = Path.GetFileNameWithoutExtension(customer.ImageFile.FileName);
                    string extension = Path.GetExtension(customer.ImageFile.FileName);
                    customer.ProfileImage = fileName + "_" + DateTime.Now.ToString("ddMMyyyy") + extension;
                    //create folder
                    Directory.CreateDirectory(rootFolder);

                    string filePath = Path.Combine(rootFolder, fileName);
                    using (var fs = new FileStream(filePath, FileMode.Create))
                    {
                        await customer.ImageFile.CopyToAsync(fs);
                    }

                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .FirstOrDefaultAsync(m => m.Id == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customer = await _context.Customer.FindAsync(id);

            string filePath = Path.Combine(_hostingEnvironment.WebRootPath, "Images", customer.ProfileImage);
            if (System.IO.File.Exists(filePath))
                System.IO.File.Delete(filePath);

            _context.Customer.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return _context.Customer.Any(e => e.Id == id);
        }
    }
}
